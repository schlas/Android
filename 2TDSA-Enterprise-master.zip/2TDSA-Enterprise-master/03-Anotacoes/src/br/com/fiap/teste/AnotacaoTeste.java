package br.com.fiap.teste;

import java.util.Date;
import java.util.Scanner;

public class AnotacaoTeste {

	@SuppressWarnings("all")
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Date data = new Date(""); //Deprecated
	}
	
}