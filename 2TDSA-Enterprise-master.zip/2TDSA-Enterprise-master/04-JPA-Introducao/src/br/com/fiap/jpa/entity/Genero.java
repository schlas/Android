package br.com.fiap.jpa.entity;

public enum Genero {

	FEMININO, MASCULINO, OUTROS;
	
}
