package br.com.fiap.jpa.entity;

public enum Periodo {

	MATUTINO, NOTURNO;
	
}
