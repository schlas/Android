package br.com.fiap.jpa.entity;

public enum Unidade {

	ACLIMACAO, PAULISTA, VILA_OLIMPIA;
	
}
